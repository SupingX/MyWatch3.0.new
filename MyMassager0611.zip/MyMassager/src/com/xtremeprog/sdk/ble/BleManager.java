//package com.xtremeprog.sdk.ble;
//
//import java.util.List;
//import java.util.UUID;
//
//import android.app.Activity;
//import android.util.Log;
//
//
//public class BleManager {
//	
//	public static final String BLE_SERVICE = "6e401523-b5a3-f393-e0a9-e50e24dcca9e";
//	public static final String BLE_CHARACTERISTIC_WRITE = "6e401523-b5a3-f393-e0a9-e50e24dcca9e";
//	public static final String BLE_CHARACTERISTIC_READ = "6e401523-b5a3-f393-e0a9-e50e24dcca9e";
//	
//	private static Activity activity;
//	private static BleManager mBlemanager;
//	private  BleGattService currentService;
//	private  BleGattCharacteristic currentCharacteristicWrite;
//	private  BleGattCharacteristic currentCharacteristicRead;
//	
//	
//	private  BleManager(Activity activity) {
//		BleManager.activity = activity;
//	}
//	
//	public static BleManager instance(Activity activity){
//		if(mBlemanager !=null){
//			return mBlemanager;
//		}
//		BleManager.activity = activity;
//		return new BleManager( activity);
//	}
//	
////	private  List<BleGattService> listBleGattServices(String address) {
////		return getIble().getServices(address);
////	}
////
////	private BleGattService getBleGattService(String address, UUID uuid) {
////		return getIble().getService(address, uuid);
////	}
//	
//	/**
//	 * 获得characteristics
//	 * @param address
//	 */
//	private  void getCharacteristics(String address) {
//		for(BleGattService s : listBleGattServices(address)) {
//			if(s.getUuid().equals(UUID.fromString(BLE_SERVICE))){
//				currentService = s ;
//				List<BleGattCharacteristic> listBleGattCharacteristics = s.getCharacteristics();
//				for (BleGattCharacteristic c : listBleGattCharacteristics) {
//					if(c.getUuid().equals(UUID.fromString(BLE_CHARACTERISTIC_WRITE))){
//						currentCharacteristicWrite = c ;
//					}
//					if(c.getUuid().equals(UUID.fromString(BLE_CHARACTERISTIC_READ))){
//						currentCharacteristicRead = c ;
//					}
//				}
//			}
//		}
//	}
//	
//	/**
//	 * 写入数据
//	 * @param address
//	 * @param value
//	 */
//	public void writeCharactics(String address, String value) {
//		try {
//			if(address==null || address.equals("")){
//				Log.e("sportReminderActivity", "地址为空");
//				return;
//			} 
//			getCharacteristics(address);
////			currentCharacteristicWrite.setValue(DataUtil.getBytesByString(value));
//			getIble().requestWriteCharacteristic(address, currentCharacteristicWrite, "");
//		} catch (Exception e) {
//			Log.e("sportReminderActivity", "写入数据失败...");
//			e.printStackTrace();
//		}
//	
//	}
//	
//	/**
//	 * 
//	 * @return
//	 */
////	public IBle getIble() {
//////		XtremApplication app = (XtremApplication) activity.getApplication();
////		return app.getIBle();
////	}
//
//}
