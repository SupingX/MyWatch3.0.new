package com.xtremeprog.sdk.ble;

import java.util.List;
import java.util.UUID;

import android.content.Intent;

import com.xtremeprog.sdk.ble.BleRequest.RequestType;

public class I2WatchBleService extends BleService {
	public static final String BLE_SERVICE = "6e401523-b5a3-f393-e0a9-e50e24dcca9e";
	public static final String BLE_CHARACTERISTIC_WRITE = "6e401523-b5a3-f393-e0a9-e50e24dcca9e";
	public static final String BLE_CHARACTERISTIC_READ = "6e401523-b5a3-f393-e0a9-e50e24dcca9e";
	@Override
	protected void bleCharacteristicWrite(String address, String uuid, int status) {
		//当前UUID是否支持匹配
		if (uuid.equals(UUID.fromString(BLE_SERVICE).toString())) {
			Intent intent = new Intent(BLE_CHARACTERISTIC_WRITE);
			intent.putExtra(EXTRA_ADDR, address);
			intent.putExtra(EXTRA_UUID, uuid);
			intent.putExtra(EXTRA_STATUS, status);
			sendBroadcast(intent);
			requestProcessed(address, RequestType.WRITE_CHARACTERISTIC, true);
		}
	}
	
	
	
	@Override
	protected void bleServiceDiscovered(String address) {
		
		List<BleGattService> services = super.getBle().getServices(address);
		
		super.bleServiceDiscovered(address);
	}
}
